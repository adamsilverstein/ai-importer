window.YTD.tweets.part0 = [
  {
    "tweet": {
      "edit_info": {"initial": {"editTweetIds": ["1750000000000000001"]}},
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [{"text": "WordPress", "indices": [15, 25]}],
        "urls": [],
        "user_mentions": []
      },
      "display_text_range": ["0", "50"],
      "favorite_count": "12",
      "id_str": "1750000000000000001",
      "truncated": false,
      "retweet_count": "3",
      "id": "1750000000000000001",
      "created_at": "Mon Jan 15 10:15:00 +0000 2024",
      "favorited": false,
      "full_text": "Hello world! #WordPress is amazing for content management.",
      "lang": "en",
      "user_id_str": "123456789"
    }
  },
  {
    "tweet": {
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": [{"screen_name": "someuser", "name": "Some User", "id_str": "987654321", "indices": [0, 9]}]
      },
      "favorite_count": "0",
      "id_str": "1750000000000000002",
      "in_reply_to_status_id_str": "1749999999999999999",
      "in_reply_to_user_id_str": "987654321",
      "retweet_count": "0",
      "id": "1750000000000000002",
      "created_at": "Tue Jan 16 14:30:00 +0000 2024",
      "full_text": "@someuser Thanks for sharing that article!",
      "lang": "en",
      "user_id_str": "123456789"
    }
  },
  {
    "tweet": {
      "retweeted": true,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": [{"screen_name": "anotheruser", "name": "Another User", "id_str": "111222333", "indices": [3, 15]}]
      },
      "favorite_count": "0",
      "id_str": "1750000000000000003",
      "retweet_count": "0",
      "id": "1750000000000000003",
      "created_at": "Wed Jan 17 09:00:00 +0000 2024",
      "full_text": "RT @anotheruser: Check out this cool new plugin for WordPress!",
      "lang": "en",
      "user_id_str": "123456789"
    }
  },
  {
    "tweet": {
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": [],
        "media": [
          {
            "media_url_https": "https://pbs.twimg.com/media/example123.jpg",
            "type": "photo",
            "id_str": "9990000001"
          }
        ]
      },
      "extended_entities": {
        "media": [
          {
            "media_url_https": "https://pbs.twimg.com/media/example123.jpg",
            "type": "photo",
            "id_str": "9990000001"
          }
        ]
      },
      "favorite_count": "5",
      "id_str": "1750000000000000004",
      "retweet_count": "1",
      "id": "1750000000000000004",
      "created_at": "Thu Jan 18 16:45:00 +0000 2024",
      "full_text": "https://t.co/abc123",
      "lang": "und",
      "user_id_str": "123456789"
    }
  },
  {
    "tweet": {
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      },
      "favorite_count": "2",
      "id_str": "1750000000000000005",
      "in_reply_to_status_id_str": "1750000000000000001",
      "in_reply_to_user_id_str": "123456789",
      "retweet_count": "0",
      "id": "1750000000000000005",
      "created_at": "Fri Jan 19 11:00:00 +0000 2024",
      "full_text": "Following up on my previous tweet - here are some more thoughts on WordPress development and why it matters.",
      "lang": "en",
      "user_id_str": "123456789"
    }
  }
]
